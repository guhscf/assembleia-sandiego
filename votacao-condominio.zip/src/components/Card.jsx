export default function Card({ children }) {
  return (
    <div className="bg-white/80 backdrop-blur-md p-10 rounded-3xl shadow-xl w-full max-w-sm border border-gray-100">
      {children}
    </div>
  );
}
