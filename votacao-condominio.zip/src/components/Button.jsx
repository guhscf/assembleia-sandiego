export default function Button({ text, onClick, loading }) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className={`w-full py-3 rounded-xl font-semibold text-white shadow-md transition-all duration-300 ${
        loading
          ? "bg-gray-400 cursor-not-allowed"
          : "bg-gradient-to-r from-sky-400 via-indigo-400 to-purple-400 hover:brightness-110"
      }`}
    >
      {loading ? "Carregando..." : text}
    </button>
  );
}
