import { useEffect, useState } from "react";
import { signOut, onAuthStateChanged } from "firebase/auth";
import { auth, db } from "../firebase";
import { doc, getDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";

export default function Navbar({ mostrarVoltar = false }) {
  const [usuario, setUsuario] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const docRef = doc(db, "usuarios", user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUsuario({
            nome: data.nome || user.email.split("@")[0],
            email: user.email,
            role: data.role || "morador",
          });
        } else {
          setUsuario({
            nome: user.email.split("@")[0],
            email: user.email,
            role: "morador",
          });
        }
      } else {
        setUsuario(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/");
  };

  return (
    <nav className="bg-white/40 backdrop-blur-md border-b border-white/30 shadow-sm fixed top-0 left-0 w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-0">
        {/* Esquerda - Voltar ou título */}
        <div className="flex items-center gap-3 sm:gap-4">
          {mostrarVoltar ? (
            <button
              onClick={() => navigate(-1)}
              className="text-indigo-600 hover:text-indigo-800 font-medium transition text-sm sm:text-base"
            >
              ← Voltar
            </button>
          ) : (
            <h1 className="text-lg sm:text-2xl font-semibold text-gray-800 text-center sm:text-left">
              Assembleias{" "}
              <span className="text-indigo-500">Residencial San Diego</span>
            </h1>
          )}
        </div>

        {/* Direita - Usuário + Sair */}
        {usuario && (
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-2 sm:gap-3">
            <div className="text-center sm:text-right">
              <p className="text-sm sm:text-base font-semibold text-gray-700 leading-tight">
                {usuario.nome}
              </p>
              <p className="text-xs text-gray-500">
                {usuario.role === "admin" ? "Administrador" : "Morador"}
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="px-3 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-sky-500 text-white font-medium flex items-center gap-1 hover:opacity-90 transition text-sm"
            >
              <LogOut size={16} className="hidden sm:block" />
              <span>Sair</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
