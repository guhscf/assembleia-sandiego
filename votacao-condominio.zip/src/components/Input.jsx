export default function Input({ label, type, value, onChange, placeholder }) {
  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-600 mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-300 focus:border-indigo-400 outline-none text-gray-700 text-[15px] transition-all duration-300 shadow-sm hover:shadow-md"
        required
      />
    </div>
  );
}
