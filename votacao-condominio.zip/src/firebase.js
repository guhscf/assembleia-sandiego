// 🔥 Configuração direta do Firebase (sem variáveis de ambiente)
import { initializeApp } from "firebase/app";
import {
  getAuth,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  collection,
  getDocs,
  query,
  where,
  deleteDoc,
} from "firebase/firestore";

// ✅ Inicializa primeiro o app e só depois exporta o resto
const firebaseConfig = {
  apiKey: "AIzaSyCot5JdiY-QYPGOBJ75UYYu4GkgAUZgSpY",
  authDomain: "votacao-sandiego.firebaseapp.com",
  projectId: "votacao-sandiego",
  storageBucket: "votacao-sandiego.firebasestorage.app",
  messagingSenderId: "936386447775",
  appId: "1:936386447775:web:2f5024e5be258549ced5aa",
  measurementId: "G-N2VLLTK69K"
};

// 🚀 Inicializa o app ANTES de usar auth/db
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// 👇 Agora o onAuthStateChanged pode usar o auth normalmente
export const observarUsuario = (callback) => {
  return onAuthStateChanged(auth, (user) => {
    callback(user);
  });
};

// 🔹 Exportações extras
export {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  doc,
  getDoc,
  setDoc,
  getDocs,
  collection,
  query,
  where,
  deleteDoc,
};
