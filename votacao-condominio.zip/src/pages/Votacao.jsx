import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { auth, db } from "../firebase";
import { collection, addDoc, query, where, getDocs } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import Swal from "sweetalert2";
import Navbar from "../components/Navbar";

export default function Votacao() {
  const location = useLocation();
  const navigate = useNavigate();
  const assembleia = location.state?.assembleia;

  const [usuario, setUsuario] = useState(null);
  const [votoFeito, setVotoFeito] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!assembleia) {
      navigate("/evento");
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        navigate("/");
        return;
      }

      // Busca dados do usuário logado
      const usuariosSnap = await getDocs(
        query(collection(db, "usuarios"), where("__name__", "==", user.uid))
      );
      if (!usuariosSnap.empty) {
        const dados = usuariosSnap.docs[0].data();
        setUsuario({ ...dados, id: user.uid });

        // Verifica se já votou
        const votosRef = collection(db, "votos");
        const votosSnap = await getDocs(
          query(votosRef,
            where("idAssembleia", "==", assembleia.idAssembleia),
            where("idUsuario", "==", user.uid)
          )
        );

        if (!votosSnap.empty) setVotoFeito(true);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [assembleia, navigate]);

  const registrarVoto = async (opcao) => {
    if (!usuario || votoFeito) return;

    try {
      await addDoc(collection(db, "votos"), {
        idAssembleia: assembleia.idAssembleia,
        idUsuario: usuario.id,
        bloco: usuario.bloco,
        apartamento: usuario.apartamento,
        voto: opcao,
        dataVoto: new Date(),
      });

      setVotoFeito(true);
      Swal.fire({
        title: "Voto registrado!",
        text: `Seu voto em "${opcao}" foi registrado com sucesso.`,
        icon: "success",
        confirmButtonColor: "#4f46e5",
      });
    } catch (error) {
      console.error(error);
      Swal.fire({
        title: "Erro ao votar",
        text: "Ocorreu um problema ao registrar seu voto.",
        icon: "error",
        confirmButtonColor: "#ef4444",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen text-gray-600">
        Carregando assembleia...
      </div>
    );
  }

  if (!assembleia) {
    return (
      <div className="flex justify-center items-center min-h-screen text-gray-600">
        Nenhuma assembleia encontrada.
      </div>
    );
  }

  const dataFormatada = new Date(assembleia.data).toLocaleString("pt-BR", {
    dateStyle: "long",
    timeStyle: "short",
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100">
      <Navbar mostrarVoltar={true} />

      <div className="max-w-2xl mx-auto bg-white/40 backdrop-blur-md shadow-lg border border-white/30 rounded-3xl p-10 mt-24 text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">
          {assembleia.titulo}
        </h1>
        <p className="text-gray-600 mb-1">{assembleia.descricao}</p>
        <p className="text-gray-500 text-sm mb-6">
          Data: {dataFormatada}
        </p>

        {!votoFeito ? (
          <div className="flex flex-col gap-3 items-center">
            {assembleia.opcoes.map((opcao, index) => (
              <button
                key={index}
                onClick={() => registrarVoto(opcao)}
                className="w-full md:w-3/4 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 text-white font-semibold shadow-md hover:opacity-90 transition"
              >
                {opcao}
              </button>
            ))}
          </div>
        ) : (
          <div className="mt-6 text-green-600 font-medium">
            ✅ Seu voto já foi registrado. Obrigado pela participação!
          </div>
        )}
      </div>
    </div>
  );
}
