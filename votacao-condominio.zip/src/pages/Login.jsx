import { useState } from "react";
import { signInWithEmailAndPassword, signOut } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "../firebase";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

export default function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const cred = await signInWithEmailAndPassword(auth, email, senha);
      const user = cred.user;
      const ref = doc(db, "usuarios", user.uid);
      const snap = await getDoc(ref);

      if (!snap.exists()) {
        await signOut(auth);
        Swal.fire("Erro", "Usuário não encontrado no banco de dados.", "error");
        return;
      }

      const data = snap.data();

      if (!data.ativo) {
        await signOut(auth);
        Swal.fire(
          "Aguardando aprovação",
          "Sua conta ainda não foi aprovada pelo administrador.",
          "info"
        );
        return;
      }

      Swal.fire({
        title: "Login realizado!",
        text: `Bem-vindo(a), ${data.role === "admin" ? "Administrador" : "Morador"}!`,
        icon: "success",
        showConfirmButton: false,
        timer: 1500,
      });

      // Redireciona com base no perfil
      if (data.role === "admin") navigate("/admin");
      else navigate("/votacao");
    } catch (error) {
      console.error(error);
      Swal.fire("Erro ao entrar", "E-mail ou senha incorretos.", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100">
      <div className="w-full max-w-md p-10 rounded-3xl bg-white/40 backdrop-blur-md shadow-lg border border-white/30">
        <h1 className="text-4xl font-bold text-gray-800 mb-2 text-center">
          Faça seu login<span className="text-indigo-500">.</span>
        </h1>
        <p className="text-center text-gray-600 mb-10 text-sm">
          Acesse sua conta para participar da assembleia
        </p>

        <form onSubmit={handleLogin} className="flex flex-col gap-6">
          <input
            type="email"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />

          <div className="flex justify-between text-sm text-indigo-600 mt-2">
            <button
              type="button"
              onClick={() => navigate("/recuperar-senha")}
              className="hover:text-indigo-700 transition"
            >
              Esqueci minha senha
            </button>
            <button
              type="button"
              onClick={() => navigate("/cadastro")}
              className="hover:text-indigo-700 transition"
            >
              Cadastrar-se
            </button>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full mt-4 py-4 rounded-xl text-white font-semibold text-lg shadow-md transition-transform transform hover:scale-[1.02] ${
              loading
                ? "bg-indigo-300 cursor-not-allowed"
                : "bg-gradient-to-r from-sky-500 to-indigo-500 hover:opacity-90"
            }`}
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
      </div>
    </div>
  );
}