import { useEffect, useState } from "react";
import { collection, getDocs, updateDoc, doc, deleteDoc } from "firebase/firestore";
import { db } from "../firebase";
import Swal from "sweetalert2";
import Navbar from "../components/Navbar"; // ✅ Importa a Navbar

export default function Usuarios() {
  const [usuarios, setUsuarios] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregarUsuarios = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "usuarios"));
        const lista = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setUsuarios(lista);
      } catch (error) {
        console.error("Erro ao carregar usuários:", error);
        Swal.fire({
          title: "Erro",
          text: "Não foi possível carregar os usuários.",
          icon: "error",
        });
      } finally {
        setLoading(false);
      }
    };
    carregarUsuarios();
  }, []);

  const aprovarUsuario = async (id, nomeOuEmail) => {
    try {
      await updateDoc(doc(db, "usuarios", id), { ativo: 1 });
      Swal.fire({
        title: "Usuário aprovado!",
        text: `${nomeOuEmail} agora pode acessar o sistema.`,
        icon: "success",
        confirmButtonColor: "#4f46e5",
      });
      setUsuarios((prev) =>
        prev.map((u) => (u.id === id ? { ...u, ativo: 1 } : u))
      );
    } catch (error) {
      console.error("Erro ao aprovar:", error);
      Swal.fire({
        title: "Erro",
        text: "Não foi possível aprovar o usuário.",
        icon: "error",
      });
    }
  };

  const excluirUsuario = async (id, nomeOuEmail) => {
    const confirma = await Swal.fire({
      title: "Excluir cadastro?",
      text: `O usuário ${nomeOuEmail} será removido permanentemente.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sim, excluir",
      cancelButtonText: "Cancelar",
      confirmButtonColor: "#ef4444",
      background: "#f9fafb",
    });

    if (!confirma.isConfirmed) return;

    try {
      await deleteDoc(doc(db, "usuarios", id));
      Swal.fire({
        title: "Excluído!",
        text: `${nomeOuEmail} foi removido do sistema.`,
        icon: "success",
        confirmButtonColor: "#4f46e5",
      });
      setUsuarios((prev) => prev.filter((u) => u.id !== id));
    } catch (error) {
      console.error("Erro ao excluir:", error);
      Swal.fire({
        title: "Erro",
        text: "Não foi possível excluir o usuário.",
        icon: "error",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen text-gray-600">
        Carregando usuários...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ✅ Navbar fixa no topo */}
      <Navbar mostrarVoltar={true} />

      <div className="max-w-6xl mx-auto bg-white shadow-lg rounded-2xl p-8 mt-20">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          Painel Administrativo<span className="text-indigo-500">.</span>
        </h1>

        <h2 className="text-lg font-semibold mb-4 text-gray-700">
          Usuários cadastrados
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-indigo-100 text-gray-700 text-sm">
                <th className="p-3 text-left">E-mail</th>
                <th className="p-3 text-left">CPF</th>
                <th className="p-3 text-left">Bloco</th>
                <th className="p-3 text-left">Apartamento</th>
                <th className="p-3 text-center">Tipo</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-center">Ações</th>
              </tr>
            </thead>

            <tbody>
              {usuarios.length > 0 ? (
                usuarios.map((u) => (
                  <tr
                    key={u.id}
                    className={`border-b text-sm ${
                      u.ativo === 0
                        ? "bg-yellow-50"
                        : u.ativo === 1
                        ? "hover:bg-green-50"
                        : "bg-gray-100"
                    }`}
                  >
                    <td className="p-3">{u.email}</td>
                    <td className="p-3">{u.cpf}</td>
                    <td className="p-3">{u.bloco}</td>
                    <td className="p-3">{u.apartamento}</td>

                    {/* 🟦 Tipo do usuário */}
                    <td className="p-3 text-center">
                      {u.role === "admin" ? (
                        <span className="px-3 py-1 bg-blue-100 text-blue-700 font-semibold text-xs rounded-full">
                          Admin
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-gray-100 text-gray-700 font-medium text-xs rounded-full">
                          Morador
                        </span>
                      )}
                    </td>

                    {/* 🟢 Status */}
                    <td className="p-3 text-center">
                      {u.ativo === 1 ? (
                        <span className="text-green-600 font-medium">Ativo</span>
                      ) : u.ativo === 0 ? (
                        <span className="text-yellow-600 font-medium">
                          Pendente
                        </span>
                      ) : (
                        <span className="text-red-600 font-medium">Removido</span>
                      )}
                    </td>

                    {/* ⚙️ Ações */}
                    <td className="p-3 text-center">
                      {u.ativo === 0 && (
                        <>
                          <button
                            onClick={() => aprovarUsuario(u.id, u.email)}
                            className="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded-md text-sm mr-2"
                          >
                            Aprovar
                          </button>
                          <button
                            onClick={() => excluirUsuario(u.id, u.email)}
                            className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded-md text-sm"
                          >
                            Recusar
                          </button>
                        </>
                      )}
                      {u.ativo === 1 && (
                        <button
                          onClick={() => excluirUsuario(u.id, u.email)}
                          className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded-md text-sm"
                        >
                          Excluir
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" className="text-center py-6 text-gray-500">
                    Nenhum usuário encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
