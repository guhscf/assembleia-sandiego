import { useState } from "react";
import {
  createUserWithEmailAndPassword,
} from "firebase/auth";
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  setDoc,
} from "firebase/firestore";
import { auth, db } from "../firebase";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

export default function Cadastro() {
  const [email, setEmail] = useState("");
  const [cpf, setCpf] = useState("");
  const [bloco, setBloco] = useState("");
  const [apartamento, setApartamento] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const formatarCPF = (valor) => {
    return valor
      .replace(/\D/g, "")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  };

  const handleCadastro = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!email || !cpf || !bloco || !apartamento || !senha || !confirmarSenha) {
        await Swal.fire("Atenção", "Preencha todos os campos!", "warning");
        return;
      }

      if (senha !== confirmarSenha) {
        await Swal.fire("Erro", "As senhas não conferem!", "error");
        return;
      }

      // Verifica duplicidade
      const qEmail = query(collection(db, "usuarios"), where("email", "==", email));
      const qCpf = query(collection(db, "usuarios"), where("cpf", "==", cpf));
      const [snapEmail, snapCpf] = await Promise.all([
        getDocs(qEmail),
        getDocs(qCpf),
      ]);

      if (!snapEmail.empty) {
        await Swal.fire("Erro", "Este e-mail já está cadastrado!", "error");
        return;
      }
      if (!snapCpf.empty) {
        await Swal.fire("Erro", "Este CPF já está cadastrado!", "error");
        return;
      }

      // Cria o usuário no Auth
      const cred = await createUserWithEmailAndPassword(auth, email, senha);
      const user = cred.user;

      // Salva no Firestore
      await setDoc(doc(db, "usuarios", user.uid), {
        uid: user.uid,
        email,
        cpf,
        bloco,
        apartamento,
        role: "morador",
        ativo: false,
        dataCadastro: new Date(),
      });

      // Mostra popup e só depois navega
      await Swal.fire({
        title: "Cadastro enviado!",
        text: "Seu cadastro foi enviado para aprovação do administrador.",
        icon: "success",
        confirmButtonText: "OK",
        confirmButtonColor: "#4F46E5",
      });

      navigate("/");
    } catch (erro) {
      console.error(erro);
      let msg = "Não foi possível realizar o cadastro.";
      if (erro.code === "auth/email-already-in-use")
        msg = "Este e-mail já está em uso.";
      if (erro.code === "auth/weak-password")
        msg = "A senha deve ter pelo menos 6 caracteres.";
      await Swal.fire("Erro", msg, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100">
      <div className="w-full max-w-md p-10 rounded-3xl bg-white/40 backdrop-blur-md shadow-lg border border-white/30">
        <h1 className="text-4xl font-bold text-gray-800 mb-2 text-center">
          Cadastro<span className="text-indigo-500">.</span>
        </h1>
        <p className="text-center text-gray-600 mb-10 text-sm">
          Preencha seus dados para participar das assembleias
        </p>

        <form onSubmit={handleCadastro} className="flex flex-col gap-6">
          <input
            type="email"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="text"
            placeholder="CPF"
            value={cpf}
            onChange={(e) => setCpf(formatarCPF(e.target.value))}
            maxLength="14"
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="text"
            placeholder="Bloco"
            value={bloco}
            onChange={(e) => setBloco(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="text"
            placeholder="Apartamento"
            value={apartamento}
            onChange={(e) => setApartamento(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="password"
            placeholder="Senha"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />
          <input
            type="password"
            placeholder="Confirmar senha"
            value={confirmarSenha}
            onChange={(e) => setConfirmarSenha(e.target.value)}
            className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
            required
          />

          <div className="flex justify-between text-sm text-indigo-600 mt-2">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="hover:text-indigo-700 transition"
            >
              Já tenho conta
            </button>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full mt-4 py-4 rounded-xl text-white font-semibold text-lg shadow-md transition-transform transform hover:scale-[1.02] ${
              loading
                ? "bg-indigo-300 cursor-not-allowed"
                : "bg-gradient-to-r from-sky-500 to-indigo-500 hover:opacity-90"
            }`}
          >
            {loading ? "Enviando..." : "Cadastrar"}
          </button>
        </form>
      </div>
    </div>
  );
}
