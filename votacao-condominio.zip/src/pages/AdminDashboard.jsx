import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { Users, BarChart2, FilePlus2 } from "lucide-react"; // Ícones modernos

try {
  console.log("AdminDashboard carregado com sucesso");
} catch (e) {
  console.error("Erro ao renderizar AdminDashboard:", e);
}


export default function AdminDashboard() {
  const navigate = useNavigate();

  const opcoes = [
    {
      titulo: "Gerenciar Usuários",
      descricao: "Veja usuários pendentes, aprove ou remova cadastros.",
      rota: "/usuarios",
      cor: "from-blue-500 to-indigo-500",
      icone: <Users size={28} />,
    },
    {
      titulo: "Nova Assembleia",
      descricao: "Crie uma nova assembleia, defina pautas e opções de voto.",
      rota: "/nova-assembleia",
      cor: "from-green-500 to-emerald-500",
      icone: <FilePlus2 size={28} />,
    },
    {
      titulo: "Resultados",
      descricao: "Visualize os resultados e exporte dados das assembleias.",
      rota: "/resultados",
      cor: "from-purple-500 to-pink-500",
      icone: <BarChart2 size={28} />,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100">
      //* <Navbar mostrarVoltar={false} /> *//

      <div className="max-w-5xl mx-auto mt-24 p-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-10 text-center">
          Painel do Administrador<span className="text-indigo-500">.</span>
        </h1>

        <div className="grid md:grid-cols-3 gap-8">
          {opcoes.map((item, index) => (
            <div
              key={index}
              onClick={() => navigate(item.rota)}
              className="group bg-white/40 backdrop-blur-md border border-white/30 shadow-lg rounded-3xl p-8 text-center cursor-pointer transform transition hover:scale-[1.03] hover:shadow-xl"
            >
              <div
                className={`w-16 h-16 mx-auto mb-5 rounded-full bg-gradient-to-r ${item.cor} flex items-center justify-center text-white shadow-md group-hover:scale-[1.1] transition`}
              >
                {item.icone}
              </div>
              <h2 className="text-xl font-semibold text-gray-800 mb-2">
                {item.titulo}
              </h2>
              <p className="text-gray-600 text-sm leading-snug">{item.descricao}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
