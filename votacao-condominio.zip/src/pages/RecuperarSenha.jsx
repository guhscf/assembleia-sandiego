import { useState } from "react";
import { sendPasswordResetEmail } from "firebase/auth";
import { auth } from "../firebase";
import { useNavigate } from "react-router-dom";

export default function RecuperarSenha() {
  const [email, setEmail] = useState("");
  const [mensagem, setMensagem] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleReset = async (e) => {
    e.preventDefault();
    setMensagem("");
    setErro("");
    setLoading(true);

    try {
      await sendPasswordResetEmail(auth, email);
      setMensagem("Enviamos um link de redefinição para seu e-mail.");
    } catch (error) {
      if (error.code === "auth/user-not-found") {
        setErro("Nenhum usuário encontrado com esse e-mail.");
      } else {
        setErro("Erro ao enviar e-mail. Tente novamente.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100">
      <div className="w-full max-w-md p-10 rounded-3xl bg-white/40 backdrop-blur-md shadow-lg border border-white/30">
        <h1 className="text-3xl font-bold text-gray-800 mb-2 text-center">
          Redefinir senha<span className="text-indigo-500">.</span>
        </h1>
        <p className="text-center text-gray-600 mb-10 text-sm">
          Informe seu e-mail para receber o link de recuperação
        </p>

        <form onSubmit={handleReset} className="flex flex-col gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              E-mail
            </label>
            <input
              type="email"
              className="w-full p-4 rounded-xl border border-gray-300 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 outline-none transition text-gray-800 placeholder-gray-400"
              placeholder="exemplo@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          {mensagem && (
            <p className="text-green-600 text-center text-sm">{mensagem}</p>
          )}
          {erro && (
            <p className="text-red-500 text-center text-sm">{erro}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-4 rounded-xl text-white font-semibold text-lg shadow-md transition-transform transform hover:scale-[1.02] ${
              loading
                ? "bg-indigo-300 cursor-not-allowed"
                : "bg-gradient-to-r from-sky-500 to-indigo-500 hover:opacity-90"
            }`}
          >
            {loading ? "Enviando..." : "Enviar link"}
          </button>

          <button
            type="button"
            onClick={() => navigate("/")}
            className="text-center text-sm text-indigo-600 hover:text-indigo-700 font-medium transition mt-3"
          >
            Voltar para o login
          </button>
        </form>
      </div>
    </div>
  );
}
