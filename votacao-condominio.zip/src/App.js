import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "./firebase";
import { doc, getDoc } from "firebase/firestore";

import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import EventoAccess from "./pages/EventoAccess";
import Votacao from "./pages/Votacao";
import NovaAssembleia from "./pages/NovaAssembleia";
import AdminDashboard from "./pages/AdminDashboard";
import Usuarios from "./pages/Usuarios";
import Resultados from "./pages/Resultados";

export default function App() {
  const [usuario, setUsuario] = useState(null);
  const [perfil, setPerfil] = useState(null); // admin ou morador
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const ref = doc(db, "usuarios", user.uid);
        const snap = await getDoc(ref);

        if (snap.exists()) {
          const data = snap.data();
          if (data.ativo) {
            setUsuario(user);
            setPerfil(data.role);
          } else {
            await auth.signOut();
            setUsuario(null);
            setPerfil(null);
          }
        } else {
          await auth.signOut();
          setUsuario(null);
          setPerfil(null);
        }
      } else {
        setUsuario(null);
        setPerfil(null);
      }
      setCarregando(false);
    });

    return () => unsubscribe();
  }, []);

  if (carregando) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-100 text-gray-700 text-lg font-medium">
        Carregando...
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Página inicial: sempre o Login */}
        <Route path="/" element={<Login />} />

        {/* Cadastro público */}
        <Route
          path="/cadastro"
          element={!usuario ? <Cadastro /> : <Navigate to="/" />}
        />

        {/* Evento público */}
        <Route path="/evento" element={<EventoAccess />} />

        {/* Rotas protegidas */}
        <Route
          path="/votacao"
          element={
            usuario && perfil === "morador" ? (
              <Votacao />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        <Route
          path="/admin"
          element={
            usuario && perfil === "admin" ? (
              <AdminDashboard />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        <Route
          path="/nova-assembleia"
          element={
            usuario && perfil === "admin" ? (
              <NovaAssembleia />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        <Route
          path="/usuarios"
          element={
            usuario && perfil === "admin" ? <Usuarios /> : <Navigate to="/" />
          }
        />

        <Route
          path="/resultados"
          element={
            usuario && perfil === "admin" ? <Resultados /> : <Navigate to="/" />
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
